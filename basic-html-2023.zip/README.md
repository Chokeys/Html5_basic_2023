# basic-html-2023
java 개발자 과정 프론트엔드 리포지토리

## 1일차
- 웹 기본
    - HTTP 개요
- 프론트엔드 학습
    - 웹 기본구조
    - HTML 5 기본태그
    
1일차 학습내용
<!-- ![멀티미디어](https://github.com/Exit-Chokey/basic-html-2023/blob/main/image/day1.png) 사이즈 못바꿈 -->
<img src = "https://github.com/Exit-Chokey/basic-html-2023/blob/main/image/day1.png" width="300">

## 2일차
- 프론트엔드 학습
    - HTML 5 입력태그
    - CSS 3 기본
    - CSS 3 고급

 ## 3일차
 - 프론트엔드 학습
    - CSS 3 고급   
    - HTML 레이아웃
    - Grid 레이아웃

3일차 레이아웃

<img src = "https://raw.githubusercontent.com/Exit-Chokey/basic-html-2023/main/image/day3.png" width="300">

## 4일차
- 프론트엔드 학습
    - Grid 레이아웃
    - 반응형 웹
    - Javascript 기초
    - jQuery

4일차 그리드레이아웃 포토갤러리

<img src = "https://raw.githubusercontent.com/Exit-Chokey/basic-html-2023/main/image/gallery1.png" width="300">


## 5일차
-프론트엔드 학습
    - Javascript 마무리
    - Bootstrap 학습
    - 포트폴리오 웹사이트 만들기