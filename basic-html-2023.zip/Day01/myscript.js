// 외부 자바스크립트
alert('hello, javascript from Outfile');